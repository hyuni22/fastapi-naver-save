
from fastapi import FastAPI, Request
from pydantic import BaseModel
from fastapi.responses import JSONResponse
from datetime import datetime

app = FastAPI()

class AddressRequest(BaseModel):
    address: str

@app.post("/save")
async def save_address(req: AddressRequest):
    address = req.address

    # [Step 1] Selenium 자동 저장 로직 자리 (지금은 테스트용 성공 처리)
    try:
        print(f"주소 저장 시도: {address}")
        # 예: Selenium 코드 실행 후 결과 판단
        if "실패" in address:
            raise Exception("버튼 없음 오류")

        # 성공 처리
        return {
            "status": "success",
            "address": address,
            "timestamp": datetime.utcnow(),
            "message": "저장 성공"
        }

    except Exception as e:
        return JSONResponse(status_code=500, content={
            "status": "fail",
            "address": address,
            "timestamp": datetime.utcnow(),
            "message": f"저장 실패: {str(e)}"
        })
